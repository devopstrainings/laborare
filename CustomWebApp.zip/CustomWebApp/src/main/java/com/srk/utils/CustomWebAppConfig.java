package com.srk.utils;

public class CustomWebAppConfig {
	public static final String AUTH_TOKEN = "Auth_Token";
	public static String tokenExpTimeInSecs = "1800";
	
}
